/*:
 [Go to Features](@next)
 
 ## IMPORTANT
 
 Most of the time if the Playground-Project is startet for the first time it shows that it's missing files. It appears with storing the files in the "Source"-folder. My assumption is that Playground tries to start the project without having all files completly compiled... I really hope that this don't effect the judgment process. I already startet a tread in the WWDC Schoolarship Forum and other developers seem to have the same problem. Thank you :)
 

 
 # About:
 I ❤️ creating UIElements so I decided to create my own Calendar. Then I had the idea to play a small particle animation to the diferent types of events. To get faster into the zusammenhänge of the different parameters I created a Particle Creator, mit dem all meine Animationen erstellt wurden.
 
 
 ### Author:
 I am a 23 years old iOS Developer from Heilbronn, Germany. Developing iOS apps is my passion. Five of my apps are published on the App Store and more are coming. Currently I am studying Mobile Computing (App Developing) in Semester six at the Hof University Campus and I enjoy it a lot! 🙂
 
 [Marcel Hagmann 👨‍💻](http://marcelhagmann.de)
 
 
  # Annotation
 
 ### First Start
 **Please open the Assitant editor.**
 
 Running the app for the first time might be a little bit of a wait, but it's **well worth the wait** 😄
 
 ### Music 🔉
 Two events provide sounds while they are playing. Don't forget to turn up the volume :)
 
 ### License - Icons & Sounds
 Most of the icons are self-made.
 All holiday.png icons are free for personal use and also free for commercial use by https://icons8.com/
 The sounds are cc0.
 
 [Go to Features](@next)
*/
